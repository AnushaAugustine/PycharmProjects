import smtplib

# import poplib

login = 'ossdashboard@nmsworks.co.in'
password = 'NMS@123$$$'
sender = 'ossdashboard@nmsworks.co.in'
receivers = ['anusha@nmsworks.co.in', 'anittasunny@nmsworks.co.in', 'ankita@nmsworks.co.in',
             'priyavarshney@nmsworks.co.in']


TEXT = "This is just a test mail from Anusha \n"

smtpObj = smtplib.SMTP('192.168.9.243', 25)
smtpObj.login(login, password)
smtpObj.sendmail(sender, receivers, TEXT)

print "successfully sent mail"

smtpObj.close()


# server = smtplib.SMTP('192.168.9.243',995)
# server.starttls()
# server.login("anusha@nmsworks.co.in", "theres08")
#
# msg = "test mail for auto mailing"
# server.sendmail("anusha@nmsworks.co.in", "anusha@nmsworks.co.in", msg)
# server.quit()
